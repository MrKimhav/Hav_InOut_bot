from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler, MessageHandler, filters
from datetime import datetime
import os

daily = {}

def get_today():
    return datetime.now().strftime("%Y-%m-%d")

def extract_amounts(text):
    import re
    usd = sum(map(float, re.findall(r'\$([\d.]+)', text)))
    riel = sum(map(int, re.findall(r'([\d,]+)\s*៛', text.replace(",", ""))))
    return usd, riel

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    today = get_today()
    if today not in daily:
        daily[today] = {'usd': 0, 'riel': 0}

    usd, riel = extract_amounts(update.message.text)
    daily[today]['usd'] += usd
    daily[today]['riel'] += riel

async def show_total(update: Update, context: ContextTypes.DEFAULT_TYPE):
    today = get_today()
    total = daily.get(today, {'usd': 0, 'riel': 0})
    await update.message.reply_text(
        f"សរុបថ្ងៃនេះ:\n- USD: ${total['usd']:.2f}\n- Riel: {total['riel']:,}៛"
    )

if __name__ == '__main__':
    TOKEN = os.getenv("BOT_TOKEN")
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_message))
    app.add_handler(CommandHandler("total", show_total))
    app.run_polling()